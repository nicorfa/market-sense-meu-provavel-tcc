Deployment tips:
- Backend: containerize with Docker, use environment variables for NEWSAPI_KEY.
- Use a managed service for production (e.g., Vercel for frontend, Railway or Render for backend).
- Add HTTPS and enforce CORS for production.
