# Market Sense

**Market Sense** is an MVP real-time investment analysis platform that aggregates market prices, news sentiment and other public signals to generate clear, conservative buy/hold/sell recommendations for a broad audience.

## Product Pitch (commercial)
Market Sense turns complex market data into simple, actionable guidance for everyday investors and fintech products. It combines price models, news sentiment and lightweight risk controls to deliver recommendations labeled with human-friendly tags: **Strong Buy / Buy / Hold / Sell / Strong Sell** — each with a short explanation and confidence level.

Key benefits:
- **Clear recommendations** designed for mass audiences, with short 1–2 sentence explanations.
- **Transparency & trust**: every signal includes the key drivers that produced it.
- **Conservative defaults**: small suggested position sizes and built-in safety rules.
- **Easy to deploy**: lightweight FastAPI backend and React frontend (Vite).

## What's inside
- `backend/` — FastAPI service, NewsAPI connector, simple scoring engine.
- `frontend/` — React (Vite) single-file demo UI.
- `docs/` — product notes, disclaimers and deployment tips.

## Quick demo (local)
1. Backend:
   - Create virtualenv, install deps from `backend/requirements.txt`.
   - Set `NEWSAPI_KEY` in environment.
   - Run: `uvicorn src.main:app --reload --port 8000`
2. Frontend:
   - `cd frontend && npm install && npm run dev`
3. Open the frontend (default Vite URL) and request a signal.

## Important legal note
This repository is an MVP demonstration. It is not financial advice, and must not be used to trade real money without proper regulation, KYC/AML, and integration with licensed brokers.

## License
MIT — see `LICENSE` file.
