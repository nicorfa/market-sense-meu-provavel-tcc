import os
import httpx
from datetime import datetime

NEWSAPI_KEY = os.getenv('NEWSAPI_KEY')
BASE = 'https://newsapi.org/v2/everything'

async def fetch_news_for_symbol(symbol: str, since: datetime):
    q = f'"{symbol}" OR {symbol}'
    params = {
        'q': q,
        'from': since.isoformat(),
        'language': 'en',
        'pageSize': 30,
        'sortBy': 'publishedAt',
        'apiKey': NEWSAPI_KEY
    }
    async with httpx.AsyncClient(timeout=20) as client:
        r = await client.get(BASE, params=params)
        r.raise_for_status()
        data = r.json()
        return data.get('articles', [])
