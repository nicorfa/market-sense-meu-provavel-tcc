from fastapi import FastAPI
from pydantic import BaseModel
from datetime import datetime, timedelta
import os
from .connectors.newsapi import fetch_news_for_symbol
from .scoring import compute_signal_for_symbol

app = FastAPI(title="Market Sense - MVP")

class SignalOut(BaseModel):
    symbol: str
    score: float
    label: str
    explanation: str
    components: dict
    ts: datetime

@app.get('/signals', response_model=SignalOut)
async def get_signal(symbol: str):
    symbol = symbol.upper()
    since = datetime.utcnow() - timedelta(hours=2)
    articles = await fetch_news_for_symbol(symbol, since)
    signal = await compute_signal_for_symbol(symbol, articles)
    return signal

@app.get('/health')
async def health():
    return {"status":"ok"}
