from datetime import datetime
from pydantic import BaseModel

def price_model(symbol: str) -> float:
    s = (sum(ord(c) for c in symbol) % 200) / 100.0 - 1.0
    return max(-1.0, min(1.0, s))

async def news_sentiment(articles) -> float:
    if not articles: return 0.0
    pos = ['gain','positive','rise','increase','profit','beat']
    neg = ['loss','down','drop','decline','miss','investigation','lawsuit']
    scores = []
    for a in articles:
        txt = (a.get('title','')+' '+(a.get('description') or '')).lower()
        sc = 0
        for w in pos:
            if w in txt: sc += 0.6
        for w in neg:
            if w in txt: sc -= 0.8
        scores.append(max(-1, min(1, sc)))
    return sum(scores)/len(scores)

class SignalObj(BaseModel):
    symbol: str
    score: float
    label: str
    explanation: str
    components: dict
    ts: datetime

async def compute_signal_for_symbol(symbol: str, articles) -> SignalObj:
    p = price_model(symbol)
    n = await news_sentiment(articles)
    score = 0.5 * p + 0.4 * n + 0.1 * 0.0
    score = max(-1.0, min(1.0, score))
    if score > 0.6:
        label = 'Strong BUY'
    elif score > 0.2:
        label = 'BUY'
    elif score >= -0.2:
        label = 'HOLD'
    elif score >= -0.6:
        label = 'SELL'
    else:
        label = 'Strong SELL'
    explanation = f"Score components -> price: {p:.2f}, news: {n:.2f}."
    components = {'price_model': p, 'news_impact': n}
    return SignalObj(symbol=symbol, score=round(score,3), label=label, explanation=explanation, components=components, ts=datetime.utcnow())
