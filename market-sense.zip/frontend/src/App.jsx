import React, {useState} from 'react'

const API = 'http://localhost:8000'

export default function App(){
  const [symbol, setSymbol] = useState('AAPL')
  const [signal, setSignal] = useState(null)

  async function fetchSignal(){
    const res = await fetch(`${API}/signals?symbol=${encodeURIComponent(symbol)}`)
    const j = await res.json()
    setSignal(j)
  }

  return (
    <div style={{padding:20,fontFamily:'Arial,Helvetica'}}>
      <h1>Market Sense — Signals</h1>
      <div>
        <input value={symbol} onChange={e=>setSymbol(e.target.value)} />
        <button onClick={fetchSignal}>Get signal</button>
      </div>
      {signal && (
        <div style={{marginTop:20,border:'1px solid #ddd',padding:12,borderRadius:8}}>
          <h2>{signal.symbol} — {signal.label} ({signal.score})</h2>
          <p>{signal.explanation}</p>
          <pre style={{fontSize:12}}>{JSON.stringify(signal.components,null,2)}</pre>
          <small>Default suggested position: conservative (0.5% of portfolio). See Terms.</small>
        </div>
      )}
      <div style={{marginTop:30,color:'#666'}}>
        <strong>Notice:</strong> This system is informational and not financial advice.
      </div>
    </div>
  )
}
